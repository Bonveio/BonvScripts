#ifndef __SMB_LM_SMBVAL_SMBDES_H
#define __SMB_LM_SMBVAL_SMBDES_H

extern void E_P16(unsigned char *p14, unsigned char *p16);
extern void E_P24(unsigned char *p21, unsigned char *c8, unsigned char *p24);

#endif /* __SMB_LM_SMBVAL_SMBDES_H */
